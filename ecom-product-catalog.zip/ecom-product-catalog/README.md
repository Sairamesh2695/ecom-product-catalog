"# ecom-product-catalog"  git init git add README.md git commit -m "first commit" git branch -M main git remote add origin https://github.com/EmbarkXOfficial/ecom-product-catalog.git git push -u origin main
"# ecom-product-catalog"  git init git add README.md git commit -m "first commit" git branch -M main git remote add origin https://github.com/EmbarkXOfficial/ecom-product-catalog.git git push -u origin main
"# ecom-product-catalog" 
